<?php get_header();?>

<?php get_template_part('inc','navbar');?>

<!--archive-pengajar.php-->

<section id="pageContent" class="uk-section">
	<div class="uk-container">
		<div class="uk-height-small">
		</div>
		<h2>Profil Pengajar</h2>
		<div uk-grid>
			<div class="uk-width-1-3@s">
				
				<p>Tutor PKBM Pelita Pratama senantiasa memberikan kegiatan belajar mengajar yang utuh dan terarah bagi warga belajar di semua jenjang pendidikan dengan latar belakang pendidikan dan pengalaman yang unggul.</p>
			</div>
			<div class="uk-width-2-3@s">
				<div class="uk-child-width-1-2@s" uk-grid>

					<?php
					$archiveTutor = new WP_Query(array(
						'post_type' => 'pengajar',
						'posts_per_page' => -1,

					));
					 while($archiveTutor->have_posts()) {
						 $archiveTutor->the_post(); ?>             

					<div>
						<article class="uk-grid-small uk-flex-middle" uk-grid>
							<div class="uk-width-1-5">
								<div class="rz-widget-tutor-avatar">
									<a href="<?php the_permalink();?>"><img src="<?php the_post_thumbnail_url('thumbnail');?>" class="uk-border-circle"></a>
								</div>	
							</div>
							<div class="uk-width-4-5">
								<dl>
									<dt><a href="<?php the_permalink();?>"><?php the_title(); ?></a></dt>
									<dd>
										<?php echo wp_kses_post( get_field('mata_pelajaran') );;?>
									</dd>
								</dl>								
							</div>

						</article>
					</div>

					<?php }
					?>

				<?php wp_reset_query();?>                 

				</div>	
			</div>
		</div>
		

		
		
	</div>

</section>
		

		
<?php get_footer();?>