<?php get_header(); ?>

<?php get_template_part('inc', 'navbar'); ?>

<!-- single-karya_siswa.php -->

<section id="pageBanner" class="uk-cover-container">
    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/img/KREASI-LOGO.png" alt="" uk-cover>
</section>

<section id="pageContent" class="uk-section">
    <div class="uk-container uk-container-small">
        <div class="uk-grid-large" uk-grid>

            <div class="uk-width-3-5@s">
                <span class="rz-text-subtext">
                    <?php echo esc_html(get_field('jenis_karya')); ?>
                </span>
                <h1 class="uk-margin-remove"><?php the_title(); ?></h1>
				<div class="uk-margin">
					<?php the_content(); ?>
				</div>
                
            </div>

            <div class="uk-width-2-5@s">
                <!-- Custom Field: Foto -->
                <?php 
                $foto = get_field('foto'); 
                if ($foto) : ?>
                    <img src="<?php echo esc_url($foto['url']); ?>" alt="<?php echo esc_attr($foto['alt']); ?>" class="uk-width-1-1">
                <?php endif; ?>

                <div class="uk-margin-large-top">
                    <dl class="rz-metadata">
                        <dt>Penulis</dt>
                        <dd>
                            <?php echo esc_html(get_field('nama_siswa')); ?>
                            <br>
                            <span class="uk-text-meta">Kelas : <?php echo esc_html(get_field('kelas')); ?></span>
                        </dd>
                    </dl>
                    <dl class="rz-metadata">
                        <dt>Editor</dt>
                        <dd><?php echo esc_html(get_field('editor')); ?></dd>
                    </dl>
                </div>

            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
