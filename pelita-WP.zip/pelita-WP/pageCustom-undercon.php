<?php /* Template Name: Under Construction */ ?>

<?php get_header();?>



<section id="pageContent" class="uk-margin-large-top">
	<div class="uk-container uk-container-small">
		<div>
			<?php if (have_posts()) : ?> 
			<?php while (have_posts()) : the_post(); ?>                

			<article>
				<?php the_content(); ?>
			</article>            

			<?php endwhile; ?>
			<?php endif; ?>		
		</div>

	
	</div>
</section>
		

		
<?php get_footer();?>