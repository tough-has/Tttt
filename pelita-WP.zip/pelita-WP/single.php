<?php get_header();?>

<?php get_template_part('inc','navbar');?>

<!--single.php-->

<section id="pageContent" class="uk-section">
	<div class="uk-container uk-container-small">

        <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>                
        
        <article>
			<?php if ( has_post_thumbnail() ) : ?>
				<img src="<?php the_post_thumbnail_url('large');?>">
			<?php endif; ?>
			<div class="uk-margin">
			<span class="rz-text-subtext"><?php
                      foreach ( ( get_the_category() ) as $category ) {
                        echo $category->cat_name . ' ';
                      }
                    ?></span>
            <h1 class="uk-margin-remove"><?php the_title();?></h1>
				<span class="rz-text-meta"><?php the_time('F j, Y'); ?></span>
				<hr>
			</div>
            <?php the_content(); ?>
        </article>
		<small>
			<?php the_tags('Kata kunci: ');?>
		</small>
		
        <?php endwhile; ?>
        <?php endif; ?>    		
		
	</div>

</section>
		

		
<?php get_footer();?>