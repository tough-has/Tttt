<?php get_header();?>

<?php get_template_part('inc','navbar');?>

<!--single-galeri.php-->

<section id="pageContent" class="uk-section">
	<div class="uk-container uk-container-small">

        <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>                
        
        <article>

			<div class="uk-margin">

            <h1 class="uk-margin-remove"><?php the_title();?></h1>
				<span class="rz-text-meta"><?php the_time('F j, Y'); ?></span>
				<hr>
			</div>
            <?php the_content(); ?>
        </article>

		
        <?php endwhile; ?>
        <?php endif; ?>    		
		
	</div>

</section>
		

		
<?php get_footer();?>