<?php /* Template Name: Page with Headline */ ?>

<?php get_header();?>

<?php get_template_part('inc','navbar');?>


<section id="pageHeader">
	<div class="uk-container">
		<div class="uk-child-width-1-2@s uk-flex-middle" uk-grid>
			<div>
				<?php if( get_field('page_subtext') ): ?>
					<div class="rz-text-subtext"><?php echo wp_kses_post( get_field('page_subtext') );?></div>
				<?php endif; ?>
				
				<?php if( get_field('page_headline') ): ?>
					<h1 class="uk-margin-remove"><?php echo wp_kses_post( get_field('page_headline') );?></h1>
				<?php endif; ?>
				
				<?php if( get_field('page_lead') ): ?>
					<p><?php echo wp_kses_post( get_field('page_lead') );?></p>
				<?php endif; ?>
			</div>
			<div>
				<?php if( get_field('page_image') ): ?>
					<img src="<?php echo wp_kses_post( get_field('page_image') );?>" />
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
<!--pageCustom-headline.php-->

<section id="pageContent" class="uk-margin-large-top">
	<div class="uk-container uk-container-small">
		<div>
			<?php if (have_posts()) : ?> 
			<?php while (have_posts()) : the_post(); ?>                

			<article>
				<?php the_content(); ?>
			</article>            

			<?php endwhile; ?>
			<?php endif; ?>		
		</div>

	
	</div>
</section>
		

		
<?php get_footer();?>