<?php get_header();?>

<?php get_template_part('inc','navbar');?>

<!--archive.php-->

<section id="pageContent" class="uk-section">
    <div class="uk-container">
		

		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>                
        <article class="uk-grid-medium uk-margin-large-bottom" uk-grid>
			<div class="uk-width-1-3">
				<img src="<?php the_post_thumbnail_url('blog-media');?>" alt="">
			</div>
			<div class="uk-width-2-3">
				<h3 class="rz-heading-fluid"><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
				<span class="rz-text-meta"><?php the_time('F j, Y'); ?></span>
				<div class="uk-margin uk-visible@m rz-excerpt"><?php the_excerpt();?></div>
				<a href="<?php the_permalink();?>" class="uk-visible@s">Baca selengkapnya</a>
			</div>
        </article>
		<?php endwhile; ?>
		<?php endif; ?>   		
	</div>

</section>
		

		
<?php get_footer();?>