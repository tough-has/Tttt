<?php /* Template Name: Biaya */ ?>

<?php get_header();?>

<?php get_template_part('inc','navbar');?>


<!--page.php-->

<div class="uk-height-small"></div>

<section id="pageContent">
	<div class="uk-container">
		<div class="uk-width-4-5@m">
			<?php if (have_posts()) : ?> 
			<?php while (have_posts()) : the_post(); ?>                

			<article>
				<?php if( get_field('page_subtext') ): ?>
				<div class="rz-text-subtext">
					<?php echo wp_kses_post( get_field('page_subtext') );?>
				</div>
				<?php endif; ?>
				<h1 class="uk-margin-remove"><?php the_title();?></h1>
				<?php the_content(); ?>
			</article>            

			<?php endwhile; ?>
			<?php endif; ?>		
		</div>

		
		<div class="uk-margin-large">
		

				<?php
				// Get the specific taxonomy (paket)
				$paket = 'paket-a';

				// The query
				$args = array(
					'post_type' => 'kelas',
					'order'		=> 'ASC',
					'tax_query' => array(
						array(
							'taxonomy' => 'paket',
							'field' => 'slug',
							'terms' => $paket,
						),
					),
				);

				// The query
				$query = new WP_Query($args);

				// Get the taxonomy title
				$taxonomy_title = get_term_by('slug', $paket, 'paket')->name;

				// Display the taxonomy title as the heading
				echo '<h3>' . $taxonomy_title . '</h3>';
				?>
					
			<div class="uk-position-relative uk-visible-toggle" tabindex="-1" uk-slider="finite: true">

				<ul class="uk-slider-items uk-grid">					
					
				<?php
				// Start the loop
				if ($query->have_posts()) :
					while ($query->have_posts()) :
						$query->the_post();

						// Get the classroom name
						$classroom_name = get_the_title();

						// Get the classroom paket
						$classroom_paket = get_the_terms($post->ID, 'paket');

						// Display the list
						?>
						<li class="uk-width-3-5 uk-width-1-3@s">
							<div class="">
								<div class="rz-cardPrice">
									<h4><?php echo $classroom_name; ?></h4>
									<div class="uk-margin">
										<h5 class="uk-margin-remove">Biaya Pendidikan</h5>
										<span class="uk-label uk-label-success">Gratis</span>									
									</div>
									<div class="uk-margin">
										<h5 class="uk-margin-remove">Biaya Bangunan</h5>
										<span class="uk-text-small uk-text-meta uk-margin-bottom uk-display-block">/bulan</span>
										<dl class="uk-flex uk-flex-between">
											<dt>Reguler</dt>
											<dd><?php echo wp_kses_post( get_field('harga') );?></dd>
										</dl>
										<dl class="uk-flex uk-flex-between">
											<dt>Disc 20%</dt>
											<dd><?php echo wp_kses_post( get_field('harga_diskon') );?></dd>
										</dl>
										<dl class="uk-flex uk-flex-between">
											<dt>Disc 10%</dt>
											<dd><?php echo wp_kses_post( get_field('harga_diskon_2') );?></dd>
										</dl>
									</div>
								</div>
							</div>
						</li>
						<?php

					endwhile;
				endif;

				// Reset the post data
				wp_reset_postdata();
				?>

		
				</ul>

				<a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
				<a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slider-item="next"></a>

			</div>			
		
		</div>
		
		
		<div class="uk-margin-large">
		

				<?php
				// Get the specific taxonomy (paket)
				$paket = 'paket-b';

				// The query
				$args = array(
					'post_type' => 'kelas',
					'order'		=> 'ASC',
					'tax_query' => array(
						array(
							'taxonomy' => 'paket',
							'field' => 'slug',
							'terms' => $paket,
						),
					),
				);

				// The query
				$query = new WP_Query($args);

				// Get the taxonomy title
				$taxonomy_title = get_term_by('slug', $paket, 'paket')->name;

				// Display the taxonomy title as the heading
				echo '<h3>' . $taxonomy_title . '</h3>';
				?>
					
			<div class="uk-position-relative uk-visible-toggle" tabindex="-1" uk-slider="finite: true">

				<ul class="uk-slider-items uk-grid">					
					
				<?php
				// Start the loop
				if ($query->have_posts()) :
					while ($query->have_posts()) :
						$query->the_post();

						// Get the classroom name
						$classroom_name = get_the_title();

						// Get the classroom paket
						$classroom_paket = get_the_terms($post->ID, 'paket');

						// Display the list
						?>
						<li class="uk-width-3-5 uk-width-1-3@s">
							<div class="">
								<div class="rz-cardPrice">
									<h4><?php echo $classroom_name; ?></h4>
									<div class="uk-margin">
										<h5 class="uk-margin-remove">Biaya Pendidikan</h5>
										<span class="uk-label uk-label-success">Gratis</span>									
									</div>
									<div class="uk-margin">
										<h5 class="uk-margin-remove">Biaya Bangunan</h5>
										<span class="uk-text-small uk-text-meta uk-margin-bottom uk-display-block">/bulan</span>
										
										<dl class="uk-flex uk-flex-between">
											<dt>Reguler</dt>
											<dd><?php echo wp_kses_post( get_field('harga') );?></dd>
										</dl>
										<dl class="uk-flex uk-flex-between">
											<dt>Disc 20%</dt>
											<dd><?php echo wp_kses_post( get_field('harga_diskon') );?></dd>
										</dl>
										<dl class="uk-flex uk-flex-between">
											<dt>Disc 10%</dt>
											<dd><?php echo wp_kses_post( get_field('harga_diskon_2') );?></dd>
										</dl>
									</div>
								</div>
							</div>
						</li>
						<?php

					endwhile;
				endif;

				// Reset the post data
				wp_reset_postdata();
				?>

		
				</ul>

				<a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
				<a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slider-item="next"></a>

			</div>			
		
		</div>		
		
		
		<div class="uk-margin-large">
		

				<?php
				// Get the specific taxonomy (paket)
				$paket = 'paket-c';

				// The query
				$args = array(
					'post_type' => 'kelas',
					'order'		=> 'ASC',
					'tax_query' => array(
						array(
							'taxonomy' => 'paket',
							'field' => 'slug',
							'terms' => $paket,
						),
					),
				);

				// The query
				$query = new WP_Query($args);

				// Get the taxonomy title
				$taxonomy_title = get_term_by('slug', $paket, 'paket')->name;

				// Display the taxonomy title as the heading
				echo '<h3>' . $taxonomy_title . '</h3>';
				?>
					
			<div class="uk-position-relative uk-visible-toggle" tabindex="-1" uk-slider="finite: true">

				<ul class="uk-slider-items uk-grid">					
					
				<?php
				// Start the loop
				if ($query->have_posts()) :
					while ($query->have_posts()) :
						$query->the_post();

						// Get the classroom name
						$classroom_name = get_the_title();

						// Get the classroom paket
						$classroom_paket = get_the_terms($post->ID, 'paket');

						// Display the list
						?>
						<li class="uk-width-3-5 uk-width-1-3@s">
							<div class="">
								<div class="rz-cardPrice">
									<h4><?php echo $classroom_name; ?></h4>
									<div class="uk-margin">
										<h5 class="uk-margin-remove">Biaya Pendidikan</h5>
										<span class="uk-label uk-label-success">Gratis</span>									
									</div>
									<div class="uk-margin">
										<h5 class="uk-margin-remove">Biaya Bangunan</h5>
										<span class="uk-text-small uk-text-meta uk-margin-bottom uk-display-block">/bulan</span>
										<dl class="uk-flex uk-flex-between">
											<dt>Reguler</dt>
											<dd><?php echo wp_kses_post( get_field('harga') );?></dd>
										</dl>
										<dl class="uk-flex uk-flex-between">
											<dt>Disc 20%</dt>
											<dd><?php echo wp_kses_post( get_field('harga_diskon') );?></dd>
										</dl>
										<dl class="uk-flex uk-flex-between">
											<dt>Disc 10%</dt>
											<dd><?php echo wp_kses_post( get_field('harga_diskon_2') );?></dd>
										</dl>
									</div>
								</div>
							</div>
						</li>
						<?php

					endwhile;
				endif;

				// Reset the post data
				wp_reset_postdata();
				?>

		
				</ul>

				<a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
				<a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slider-item="next"></a>

			</div>			
		
		</div>


	
	</div>
</section>
		

		
<?php get_footer();?>