<?php get_header();?>

<div id="homePromoLine" uk-alert>
	<div class="uk-container uk-text-center">
		<a class="uk-alert-close" uk-close></a>
	<?php if ( dynamic_sidebar('hero-promo') ) : else : endif; ?>
	</div>
</div>

<?php get_template_part('inc','navbar');?>

<!--FRONT PAGE-->

<section id="homeHero" class="uk-section" uk-height-viewport="offset-bottom: 30">
	<div class="rz-hero">
		<div class="uk-container">
			<div class="uk-grid-small" uk-grid>
				<div class="uk-width-1-2@s uk-flex uk-flex-center uk-flex-column">
					<?php if ( dynamic_sidebar('hero-subtext') ) : else : endif; ?>
					<?php if ( dynamic_sidebar('hero-title') ) : else : endif; ?>
					<?php if ( dynamic_sidebar('hero-paragraph') ) : else : endif; ?>
					<div>
					<a href="https://bit.ly/PelitaPratamaBandung" class="uk-button uk-button-primary"><span class="uk-margin-small-right" uk-icon="whatsapp"></span>Informasi</a>
					<a href="https://bit.ly/PPDBPelita" class="uk-button uk-button-small"> Daftar Online <span uk-icon="chevron-right"></span></a>
					</div>
					
				</div>
				<div class="uk-width-1-2@s">
					<?php if ( dynamic_sidebar('hero-image') ) : else : endif; ?>
				
				</div>

			</div>

		</div>	
	
	</div>


</section>

<section id="homePromo">
	<div class="uk-container">
		<?php if ( dynamic_sidebar('hero-promo-banner') ) : else : endif; ?>
	</div>
</section>

<section id="homeFeature" class="uk-section">
	<div class="uk-container" data-uk-scrollspy="cls: uk-animation-slide-left; target: *; delay: 50">
		<h2>Alasan bergabung di PKBM Pelita Pratama</h2>
		<p>Cari tahu apa yang Sobat Pelita dapatkan di PKBM Pelita Pratama</p>
		<div class="uk-child-width-1-3@s uk-margin-large-top" uk-grid>
			<div>
				<article class="uk-grid-small" uk-grid>
					<div class="uk-width-1-6">
						<img src="<?php bloginfo('template_directory');?>/img/icon-location.svg" alt="">
					</div>
					<div class="uk-width-5-6">
						<h5 class="uk-margin-remove">Lokasi Strategis</h5>
						<span>Letak gedung sekolah yang berada di tengah kota Bandung, mengefektifkan waktu Sobat Pelita untuk belajar di sekolah.</span>
					</div>
				</article>			
			</div>
			<div>
				<article class="uk-grid-small" uk-grid>
					<div class="uk-width-1-6">
						<img src="<?php bloginfo('template_directory');?>/img/icon-computer.svg" alt="">
					</div>
					<div class="uk-width-5-6">
						<h5 class="uk-margin-remove">Program Keterampilan</h5>
						<span>Tersedia berbagai program pengembangan keterampilan yang relevan dengan dunia kerja, usaha, dan masyarakat.</span>
					</div>
				</article>			
			</div>
			<div>
				<article class="uk-grid-small" uk-grid>
					<div class="uk-width-1-6">
						<img src="<?php bloginfo('template_directory');?>/img/icon-book.svg" alt="">
					</div>
					<div class="uk-width-5-6">
						<h5 class="uk-margin-remove">Metode Belajar</h5>
						<span>Bebas pilih program kelas yang  memudahkan kebutuhan dan latar belakang Sobat Pelita baik secara online maupun offline.</span>
					</div>
				</article>			
			</div>
			<div>
				<article class="uk-grid-small" uk-grid>
					<div class="uk-width-1-6">
						<img src="<?php bloginfo('template_directory');?>/img/icon-certificate.svg" alt="">
					</div>
					<div class="uk-width-5-6">
						<h5 class="uk-margin-remove">Ijazah Resmi</h5>
						<span>Sobat Pelita akan mendapatkan ijazah resmi yang dapat digunakan untuk melanjutkan pendidikan ke yang lebih tinggi.</span>
					</div>
				</article>			
			</div>
			<div>
				<article class="uk-grid-small" uk-grid>
					<div class="uk-width-1-6">
						<img src="<?php bloginfo('template_directory');?>/img/icon-feather.svg" alt="">
					</div>
					<div class="uk-width-5-6">
						<h5 class="uk-margin-remove">Biaya Bangunan Ringan</h5>
						<span>Seluruh biaya bangunan di semua paket sangat ringan dan terjangkau bagi Sobat Pelita.</span>
					</div>
				</article>			
			</div>
			<div>
				<article class="uk-grid-small" uk-grid>
					<div class="uk-width-1-6">
						<img src="<?php bloginfo('template_directory');?>/img/icon-communication.svg" alt="">
					</div>
					<div class="uk-width-5-6">
						<h5 class="uk-margin-remove">Tutor Berpengalaman</h5>
						<span>Tenaga pengajar memudahkan Sobat Pelita dalam KBM karena pengalaman dan metode yang berkualitas.</span>
					</div>
				</article>			
			</div>






			
		</div>
	
	</div>
</section>


<section id="homeWhy" class="uk-section">
	<div class="uk-container" data-uk-scrollspy="cls: uk-animation-slide-bottom; target: *; delay: 200">
		<div class="uk-child-width-1-2@s uk-flex-middle" uk-grid>
			<div>
				<img src="<?php bloginfo('template_directory');?>/img/01.png" alt="">
			</div>
			<div>
				<h2>Mengapa pendidikan kesetaraan bisa mengubah masa depan?</h2>
				<p>Dengan pendidikan kesetaraan, Sobat Pelita mendapatkan kesempatan untuk melanjutkan sekolah untuk bisa meningkatkan kemampuan dan keterampilan sebagai lulusan dengan ijazah yang resmi dan diakui.</p>
				<p>Sobat Pelita dapat melangkah lebih jauh di masa depan untuk mendapatkan kesempatan kerja dan kesejahteraan yang lebih unggul. Yuk buat hati tenang dan jadi pemenang dengan <a href="<?php bloginfo('url');?>/akademik/program-paket-kesetaraan/">pendidikan kesetaraan</a> di PKBM Pelita Pratama!</p>
				<a href="https://bit.ly/PPDBPelita" class="uk-button uk-button-primary">Daftar Sekarang</a>
			</div>
		</div>
	</div>
</section>


<section id="homeProduct" class="uk-section">
	<div class="uk-container" data-uk-scrollspy="cls: uk-animation-slide-bottom; target: *; delay: 200">
		<h2>Program Paket Kesetaraan</h2>
		<p>Semua bisa belajar dan mengikuti Ujian Kesetaraan di PKBM Pelita Pratama untuk kelompok pendidikan sebagai berikut:</p>

		<div class="uk-child-width-1-3@s uk-margin-medium-top" uk-grid>
			<div>
				<h4>Paket A</h4>
				<p>Kelompok pendidikan setara Sekolah Dasar (SD) mulai kelas 1 hingga 6 SD. Mendapatkan pembelajaran dan ijazah untuk warga belajar dalam mengembangkan pengetahuan, keterampilan dan sikap setara SD.</p>
				<a href="<?php bloginfo('url');?>/akademik/program-paket-kesetaraan/" class="uk-button uk-button-default uk-button-small">Info Lengkap</a>
			</div>
			<div>
				<h4>Paket B</h4>
				<p>Kelompok pendidikan setara Sekolah Menengah Pertama (SMP) mulai dari kelas 7 hingga 9 SMP. Warga belajar Paket B akan mendapatkan ijazah setara SMP setelah mengikuti Uji Kesetaraan (UK).</p>
				<a href="<?php bloginfo('url');?>/akademik/program-paket-kesetaraan/" class="uk-button uk-button-default uk-button-small">Info Lengkap</a>
			</div>
			<div>
				<h4>Paket C</h4>
				<p>Kelompok pendidikan setara Sekolah Menengah Atas (SMA) untuk kelas 10 sampai 12 SMA dengan peminatan IPA dan IPS. Pembelajaran dan Ijazah resmi setingkat SMA, dan dapat dipergunakan untuk melanjutkan ke Perguruan Tinggi.</p>
				<a href="<?php bloginfo('url');?>/akademik/program-paket-kesetaraan/" class="uk-button uk-button-default uk-button-small">Info Lengkap</a>
			</div>

		</div>
	</div>
</section>


<secton id="homeTestimonial" class="uk-section">
	<div class="uk-container uk-container-small">
		<h2>#SuaraSobatPelita</h2>
		<p>Dengarkan apa yang Sobat Pelita rasakan selama bergabung di PKBM Pelita Pratama</p>
		
		
		<div class="uk-child-width-1-3@s uk-grid-large uk-margin-large-top" uk-grid data-uk-scrollspy="cls: uk-animation-fade; target: *; delay: 100">
			
			<?php

               $args = array(
                   'post_type' => 'testimonial',
                   'posts_per_page' => 3,
               );
               $front_testi = new WP_Query($args);

               if($front_testi->have_posts()) : 
                  while($front_testi->have_posts()) : 
                     $front_testi->the_post();
            ?>			
			
			<div>
				<article class="rz-quote">
					<div class="uk-text-center">
						<img src="<?php the_post_thumbnail_url('thumbnail');?>" alt="" class="uk-border-circle">
					</div>
					
					<blockquote><?php the_content();?></blockquote>
					<div><?php the_title();?></div>
				</article>
			</div>

			
			
            <?php endwhile; ?>
            <?php endif; ?>					
			
			
			
		</div>
	</div>
</secton>

<section id="homeFAQ" class="uk-section">
	<div class="uk-container uk-container-small">
		<h2>#JawabSobatPelita</h2>
		<p>Tidak usah bingung, cek pertanyaan ini langsung. Ketahui lebih jauh apa yang hermonies butuhkan.</p>
		<div class="uk-margin-large-top" data-uk-scrollspy="cls: uk-animation-fade; target: *; delay: 200">
			<dl>
				<dt>Bagaimana metode belajar di PKBM Pelita Pratama?</dt>
				<dd>Sobat Pelita dapat memilih metode belajar sesuai dengan kebutuhan dan kesibukan masing-masing. Tersedia kelas bersama dan independen yang bisa diakses secara online maupun belajar langsung di sekolah, dari hari Senin - Sabtu. </dd>
			</dl>
			<dl>
				<dt>Apakah Ijazah yang dikeluarkan resmi?</dt>
				<dd>Ijazah pendidikan kesetaraan PKBM Pelita Pratama bersifat resmi, diakui dan dikeluarkan langsung oleh Dinas terkait.</dd>
			</dl>
			<dl>
				<dt>Saya berada di luar kota Bandung, apakah bisa bergabung di PKBM Pelita Pratama?</dt>
				<dd>Bisa, Sobat Pelita bisa mengambil program kelas secara daring (online) atau mengambil kelas independen.</dd>
			</dl>
			<dl>
				<dt>Apakah ada batasan usia untuk menyelesaikan paket?</dt>
				<dd>Tidak ada, selama Sobat Pelita masih sanggup dan semangat dalam mengikut kegiatan pembelajaran. </dd>
			</dl>
			<dl>
				<dt>Apakah lulusan paket C bisa melanjutkan ke perguruan tinggi?</dt>
				<dd>Tentu bisa, menurut Surat Edaran Mendiknas bernomor: 107/MPN/MS/2006 menyebutkan bahwa lulusan paket A, B, dan C memiliki hak eligibilitas untuk dapat mendaftar pada satuan pendidikan yang lebih tinggi.</dd>
			</dl>
			<dl>
				<dt>Berapa lama dan materi apa saja yang saya terima dalam mengikuti program paket?</dt>
				<dd>Lama pendidikan disesuaikan dengan paket yang diambil, sedangkan materi pembelajaran disesuaikan dengan kurikulum nasional dan tambahan program pengembangan keterampilan bagi Sobat Pelita. </dd>
			</dl>
			<dl>
				<dt>Apakah biaya bangunan dapat dicicil?</dt>
				<dd>Bisa, biaya bangunan dapat dilakukan dengan metode cicilan, berdasar pada kebijakan dari Manajemen PKBM Pelita Pratama.</dd>
			</dl>
			<dl>
				<dt>Jika saya masih bingung, apakah bisa berkonsultasi terlebih dahulu dengan tim PKBM Pelita Pratama?</dt>
				<dd>Bisa, Sobat Pelita dapat menghubungi nomor Whatsapp Official PKBM Pelita Pratama di menu Kontak pada jam kerja. Sobat Pelita berkesempatan konsultasi dengan tim Pelita Pratama lebih jauh tanpa biaya apapun. </dd>
			</dl>		
		</div>
		
	</div>
</section>

<section id="homeBlog" class="uk-section">
    <div class="uk-container">
        <h2 class="uk-margin-large uk-text-center">Seputar Pelita</h2>

        <div class="uk-child-width-1-3@s" uk-grid>

            <?php

               $args = array(
                   'post_type' => 'post',
                   'posts_per_page' => 3,
               );
               $front_posts = new WP_Query($args);

               if($front_posts->have_posts()) : 
                  while($front_posts->have_posts()) : 
                     $front_posts->the_post();
            ?>
			
			
            <article>
                <div class="uk-card uk-card-default uk-card-small">
                    <div class="uk-card-media-top">
                        <a href="<?php the_permalink();?>">
                            <img src="<?php the_post_thumbnail_url('blog-media');?>" alt="">    
                        </a>
                    </div>
                    <div class="uk-card-body">
                        <span class="uk-text-uppercase"><?php
						  foreach ( ( get_the_category() ) as $category ) {
							echo $category->cat_name . ' ';
						  }
						?></span>
                        <h3 class="uk-margin-remove-top"><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                        <?php the_excerpt();?>

                        <p class="uk-text-right"><a href="<?php the_permalink();?>">Baca Selengkapnya</a></p>

                    </div>
                </div>
            </article>
			
			
            <?php endwhile; ?>
            <?php endif; ?>
			
			
        </div>
    </div>
</section>
		
<?php get_footer();?>