<?php get_header();?>

<?php get_template_part('inc','navbar');?>


<!--page.php-->

<div class="uk-height-small"></div>

<section id="pageContent">
	<div class="uk-container">
		<div class="uk-width-4-5@m">
			<?php if (have_posts()) : ?> 
			<?php while (have_posts()) : the_post(); ?>                

			<article>
				<?php if( get_field('page_subtext') ): ?>
				<div class="rz-text-subtext"><?php echo wp_kses_post( get_field('page_subtext') ); ?></div>
				<?php endif; ?>
				<h1 class="uk-margin-remove"><?php the_title();?></h1>
				<?php the_content(); ?>
			</article>            

			<?php endwhile; ?>
			<?php endif; ?>		
		</div>

	
	</div>
</section>
		

		
<?php get_footer();?>