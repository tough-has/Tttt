<?php get_header();?>

<?php get_template_part('inc','navbar');?>

<!--archive-karya_siswa.php-->

<section id="pageBanner" class="uk-cover-container">
	<img src="<?php bloginfo('template_directory');?>/img/KREASI-LOGO.png" alt="" uk-cover>
</section>


<section id="pageContent" class="uk-section">
    <div class="uk-container">
        <div class="uk-child-width-1-3@s uk-grid-small" uk-grid>
            <?php
            $args = array(
                'post_type'      => 'karya_siswa',
                'posts_per_page' => -1, // Fetch all posts
            );

            $query = new WP_Query($args);

            if ($query->have_posts()) :
                while ($query->have_posts()) : $query->the_post();
            ?>
                    <a href="<?php the_permalink(); ?>">
                        <?php if (has_post_thumbnail()) : ?>
                            <?php the_post_thumbnail('blog-thumb-3-2'); ?>
                        <?php else : ?>
                            <img src="<?php echo esc_url(get_template_directory_uri() . '/path-to-placeholder.jpg'); ?>" alt="Placeholder">
                        <?php endif; ?>
                    </a>
            <?php
                endwhile;
                wp_reset_postdata();
            else :
                echo '<p>No posts found.</p>';
            endif;
            ?>
        </div>
    </div>
</section>

		

		
<?php get_footer();?>