<?php get_header();?>

<?php get_template_part('inc','navbar');?>

<!--archive-galeri.php-->

<section id="pageContent" class="uk-section">
	<div class="uk-container uk-container-small">
		<div class="uk-child-width-1-3@s uk-child-width-1-2 uk-text-center" uk-grid>

            <?php
            $archiveGaleri = new WP_Query(array(
                'post_type' => 'galeri',
                'order'     => 'ASC',
            ));
             while($archiveGaleri->have_posts()) {
                 $archiveGaleri->the_post(); ?>             
			
			<div>
				<a href="<?php the_permalink();?>">
                    <div class="uk-inline rz-widget">
                        <img src="<?php the_post_thumbnail_url('blog-thumb');?>" alt="" class="uk-border-rounded">
                        <div class="rz-overlay-primary uk-position-cover uk-border-rounded"></div>
                        <div class="uk-overlay uk-position-bottom uk-light">
                            <h4><?php the_title();?></h4>
                        </div>
                    </div>
				</a>
			</div>

            <?php }
            ?>
        
        <?php wp_reset_query();?>   
		
		</div>
		
   		
		
		
	</div>

</section>
		

		
<?php get_footer();?>