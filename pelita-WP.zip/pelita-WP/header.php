<!DOCTYPE html>
<html lang="en">
<head>
<!-- Global site tag (gtag.js) - Google Analytics -->
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11220466676"></script>
<!-- Google Tag Manager -->
<script>
	(function (w,d,s,l,i) {
		w[l]=w[l]||[];w[l].push({
			'gtm.start':new Date().getTime(),event:'gtm.js'
			});
		var f=d.getElementsByTagName(s)[0],
			j=d.createElement(s),
			dl=l!='dataLayer'?'&l='+l:'';
		j.async=true;
		j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})
(window,document,'script','dataLayer','GTM-PHQN99FC');

</script>
<!-- End Google Tag Manager -->
<!-- Event snippet for Website traffic conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-11220466676/bj75CO7g8KsYEPT3quYp'});
</script>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>
<?php wp_title(' '); ?>
<?php if(wp_title(' ', false)) { echo ' &raquo; '; } ?>
<?php bloginfo('name'); ?>
</title>

<!-- EXTERNAL -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lora&family=Montserrat:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/uikit@latest/dist/css/uikit.min.css">

<?php wp_head();?>
</head>
<body <?php body_class(); ?>>
