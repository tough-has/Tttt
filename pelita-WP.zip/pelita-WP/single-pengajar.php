<?php get_header();?>

<?php get_template_part('inc','navbar');?>

<!--single-pengajar.php-->

<section id="pageContent" class="uk-section">
	<div class="uk-container uk-container-small">

        <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>                
        
        <article uk-grid>
			<div class="uk-width-auto">
				<?php if ( has_post_thumbnail() ) : ?>
					<img src="<?php the_post_thumbnail_url('medium');?>">
				<?php endif; ?>
			</div>
			<div class="uk-width-expand">
				<h3 class="uk-margin-remove"><?php the_title();?></h3>
				<dl>
					<dt>Mata Pelajaran</dt>
					<dd><?php echo wp_kses_post( get_field('mata_pelajaran') );?></dd>
				</dl>
				<dl>
					<dt>Pendidikan</dt>
					<dd><?php echo wp_kses_post( get_field('pendidikan') );?> - <?php echo wp_kses_post( get_field('universitas') );?></dd>				
				</dl>
			</div>

        </article>
		
        <?php endwhile; ?>
        <?php endif; ?>    		
		
	</div>

</section>
		

		
<?php get_footer();?>