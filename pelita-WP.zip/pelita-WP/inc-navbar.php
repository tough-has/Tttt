<div class="" uk-sticky="cls-active: rz-bg-white; top: 300; animation: uk-animation-slide-top">
    <div class="uk-container">
        <nav class="" uk-navbar>
            <div class="uk-navbar-left">

					<a href="<?php bloginfo('url');?>" 
					   title="<?php bloginfo('name');?>" 
					   rel="home">

						<img src="<?php bloginfo('template_directory');?>/img/pelita-logo-default.png" 
							 alt="<?php bloginfo('name');?>" class="rz-logo"/>

					</a>

            </div>
			<div class="uk-navbar-center">
				  <?php wp_nav_menu(array(
						  'container_class'	=> 'rz-main-nav',
						  'theme_location'    => 'core-menu',
						  'menu_class'        => 'uk-navbar-nav uk-visible@l',
					  )
				  );?>
			</div>
            <div class="uk-navbar-right">
              <ul class="uk-navbar-nav">
                  <li>
						<a href="https://bit.ly/PPDBPelita" target="_blank" class=""><div class="rz-button-block">Daftar</div></a>
                  </li>
                  <li>
                      <a class="uk-navbar-toggle uk-navbar-item uk-hidden@l" data-uk-toggle data-uk-navbar-toggle-icon href="#offcanvas-nav"></a>            
                  </li>
              </ul>
            </div>
        </nav>           
    </div>
</div>