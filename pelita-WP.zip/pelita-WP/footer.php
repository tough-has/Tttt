<footer class="uk-section uk-margin-top uk-light">
	<div class="uk-container">
		<div class="uk-child-width-1-4@m" uk-grid>
			<div>
				<h5>Tentang Kami</h5>
			  <?php wp_nav_menu(array(
					  'theme_location'    => 'footer-about',
					  'menu_class'        => 'uk-list',
				  )
			  );?>			
			</div>
			<div>
				<h5>Akademik</h5>
			  <?php wp_nav_menu(array(
					  'theme_location'    => 'footer-akademik',
					  'menu_class'        => 'uk-list',
				  )
			  );?>			
			</div>

			<div>
				<ul class="uk-list">
				
			 <?php
                $socialLinks = new WP_Query(array(
                    'post_type'         => 'link'
                ));
                 while($socialLinks->have_posts()) {
                     $socialLinks->the_post(); ?>

					<li><?php $link = get_field('url');?>
                        <a href="<?php echo esc_url( $link ); ?>" target="_blank">
							<span uk-icon="<?php echo wp_kses_post( get_field('icon') );?>" class="uk-margin-small-right"></span> <?php echo wp_kses_post( get_field('username') );?>
						</a>
					</li>					

                <?php }
                ?>
        
                <?php wp_reset_query();?>  				
				</ul>
	
			</div>
			<div>
				<img src="<?php bloginfo('template_directory');?>/img/pelita-logo-white.png" alt="" class="rz-logo-medium">
				<div class="uk-text-bold uk-margin-top">PKBM Pelita Pratama</div>
				<address>
					Jl. Surapati No.55 E, Sadang Serang, <br>
					Kecamatan Coblong, Kota Bandung, <br>
					Jawa Barat 40133
				</address>
			</div>
		</div>
	</div>
</footer>

<div class="rz-float-button">
	<a href="https://bit.ly/PelitaPratamaBandung" target="_blank"><span uk-icon="whatsapp"></span></a>
</div>


<!-- OFFCANVAS -->
<div id="offcanvas-nav" data-uk-offcanvas="flip: true; overlay: true">
    <div class="uk-offcanvas-bar uk-offcanvas-bar-animation uk-offcanvas-slide">
        <button class="uk-offcanvas-close uk-close uk-icon" type="button" data-uk-close></button>
          <?php wp_nav_menu(array(
                 'container_class'	=> 'rz-mobile-nav',
                  'theme_location'    => 'core-menu',
                  'menu_class'        => 'uk-nav uk-nav-default',
              )
          );?>
		<div class="uk-position-small uk-position-bottom-left">
			<img src="<?php bloginfo('template_directory');?>/img/pelita-logo-default.png" alt="" class="rz-logo uk-margin-bottom">
		</div>
    </div>
</div>
<!-- /OFFCANVAS -->


<!-- SCRIPTS -->
<?php wp_footer();?>
<script src="https://cdn.jsdelivr.net/npm/uikit@latest/dist/js/uikit.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/uikit@latest/dist/js/uikit-icons.min.js"></script>
</body>
</html>