<?php

// MENUS
register_nav_menus(
    array(
        'core-menu' => 'Core Menu',
		'mobile-menu' => 'Mobile Menu',
		'footer-about' => 'Footer Menu Profile',
		'footer-akademik' => 'Footer Menu Akademik',
    )
);

// FRONTPAGE WIDGETS
register_sidebar(
    array(
        'name'          => 'Hero Subtext',
        'id'            => 'hero-subtext',
        'class'         => '',
        'before_widget' => '<div class="rz-text-subtext">',
        'after_widget'  => '</div>',
        'before_title'  => '',
        'after_title'   => '',
    )
);
register_sidebar(
    array(
        'name'          => 'Hero Title',
        'id'            => 'hero-title',
        'class'         => '',
        'before_widget' => '<div class="kc-widget-%2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h1>',
        'after_title'   => '</h1>',
    )
);
register_sidebar(
    array(
        'name'          => 'Hero Paragraph',
        'id'            => 'hero-paragraph',
        'class'         => '',
        'before_widget' => '<div class="uk-text-lead">',
        'after_widget'  => '</div>',
        'before_title'  => '',
        'after_title'   => '',
    )
);
register_sidebar(
    array(
        'name'          => 'Hero Image',
        'id'            => 'hero-image',
        'class'         => '',
        'before_widget' => '<div>',
        'after_widget'  => '</div>',
        'before_title'  => '',
        'after_title'   => '',
    )
);
register_sidebar(
    array(
        'name'          => 'Hero Promo',
        'id'            => 'hero-promo',
        'class'         => '',
        'before_widget' => '<div>',
        'after_widget'  => '</div>',
        'before_title'  => '',
        'after_title'   => '',
    )
);
register_sidebar(
    array(
        'name'          => 'Hero Promo Banner',
        'id'            => 'hero-promo-banner',
        'class'         => '',
        'before_widget' => '<div>',
        'after_widget'  => '</div>',
        'before_title'  => '',
        'after_title'   => '',
    )
);
register_sidebar(
    array(
        'name'          => 'Frontpage Extra',
        'id'            => 'frontpage-extra',
        'class'         => '',
        'before_widget' => '<div>',
        'after_widget'  => '</div>',
        'before_title'  => '',
        'after_title'   => '',
    )
);


// create custom function to return nav menu
function custom_wp_menu() {
    // Replace your menu name, slug or ID carefully
    return wp_get_nav_menu_items('core-menu');
}

// create new endpoint route
add_action( 'rest_api_init', function () {
    register_rest_route( 'wp/v2', 'menu', array(
        'methods' => 'GET',
        'callback' => 'custom_wp_menu',
    ) );
} );


//FORMAT ACF NUMBER FORMAT 
add_filter('acf/format_value/type=number', 'fix_number', 20, 3);
function fix_number($value, $post_id, $field) {
  $value = number_format($value);
  return $value;
}



// CSS
wp_enqueue_style( 'style', get_stylesheet_uri() );

// FEATURED IMAGES
add_theme_support( 'post-thumbnails' );

// ADDITIONAL IMAGE SIZES
add_image_size( 'blog-thumb', 500, 500, true );
add_image_size( 'blog-media', 400, 300, true );
add_image_size( 'blog-thumb-3-2', 600, 400, false );

// Body open
function add_gtm_to_body() {
    ?>
    <!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PHQN99FC"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->
    <?php
}
add_action('wp_body_open', 'add_gtm_to_body');


?>