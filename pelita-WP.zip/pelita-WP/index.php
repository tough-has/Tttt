<?php get_header();?>

<?php get_template_part('inc','navbar');?>

<section id="pageContent" class="uk-section">
    <div class="uk-container uk-container-xsmall">
		

		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>                
			<article>
				<h2><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
				<?php the_excerpt(); ?>
				<hr>
			</article>
		<?php endwhile; ?>
		<?php endif; ?>   		
	</div>

</section>
		

		
<?php get_footer();?>